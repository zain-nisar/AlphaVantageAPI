# Payrails Automation



The project is implemented using RestAssured with Java language also Maven is used.

This is an assignment for testing the AlphaVantage API.

The Framework contains the following structure.

1) ConfigUtils are created to run tests on multiple environments
2) Model response classes have been created to map the responses
3) RestAssuredResource Class has been created to manage the GET PUT POST methods

## Automated Two Scenarios
1) Validated the positive scenario with Required fields
2) Parameterized test for invalid values verification
package com.payrails.configmanager;

import io.restassured.RestAssured;
import io.restassured.response.Response;

import java.util.Map;

public class RestAssuredResource {

  public static Response get(String basePath, Map<String, Object> queryParams) {
    return RestAssured.given(SpecBuilder.FetchRequestSpecification())
            .log().all()
            .queryParams(queryParams)
            .get(basePath)
            .then()
            .log().all()
            .extract()
            .response();
  }
}

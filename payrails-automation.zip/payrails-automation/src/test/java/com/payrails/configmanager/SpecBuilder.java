package com.payrails.configmanager;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.specification.RequestSpecification;

import java.util.Map;

public class SpecBuilder {

  public static RequestSpecification FetchRequestSpecification() {
    Map<String, Object> configKeys = ConfigUtils.getEnvironmentInfoFromConfig();
    Map<String, Object> getEnvKeys = (Map<String, Object>)configKeys.get("env");
    return RestAssured.requestSpecification = new RequestSpecBuilder()
        .setBaseUri((String) getEnvKeys.get("base_url"))
        .setBasePath((String) configKeys.get("base_api_path"))
        .build();
  }
}

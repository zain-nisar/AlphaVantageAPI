package com.payrails.configmanager;
import org.yaml.snakeyaml.Yaml;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Map;

public class ConfigUtils {
    private static String base_url = "";
    private static String environmentProperty = "";
    private static String authentication_url = "";

    static {
        // if we want to provide credentials via Pipeline
        base_url = System.getProperty("base_url");
        environmentProperty = System.getProperty("environment");
        authentication_url = System.getProperty("auth_url");
        }

    public static String getConfigFilePath() {
        return System.getProperty("user.dir") + "/config.yml";
    }

    public static Object readConfigFile() {
        Yaml yaml = new Yaml();
        InputStream inputStream = null;
        try {
            inputStream = new FileInputStream(getConfigFilePath());
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }

        Map<String, Object> yamlMap = yaml.load(inputStream);
        return yamlMap;
    }

    public static Map<String,Object> getEnvironmentInfoFromConfig() {
        Map<String,Object> getAllConfigKeys = (Map<String,Object>) readConfigFile();
        Map<String,Object> getEnvKeys = (Map<String,Object>)getAllConfigKeys.get("env");

        if(environmentProperty == null) {
            getEnvKeys = (Map<String,Object>)getEnvKeys.get(getAllConfigKeys.get("current_execution_environment"));
        } else {
            getEnvKeys = (Map<String,Object>)getEnvKeys.get(getAllConfigKeys.get(environmentProperty));
        }

        if(base_url != null) {
            getEnvKeys.put("base_url", base_url);
        }
        if(authentication_url != null) {
            getEnvKeys.put("authentication_url", authentication_url);
        }
        getAllConfigKeys.put("env", getEnvKeys);
        return getAllConfigKeys;
    }
}
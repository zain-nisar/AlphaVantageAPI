package com.payrails.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

import java.util.Map;

public class TimeSeriesIntradayApiResponse {

    @SerializedName("Meta Data")
    public MetaData metaData;
    @SerializedName("Time Series (1min)")
    public Map<String, TimeSeriesEntry> timeSeries;

    // Getters and setters
}


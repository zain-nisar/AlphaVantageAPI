package com.payrails.model.response;

import com.google.gson.annotations.SerializedName;

public class TimeSeriesEntry {
    @SerializedName("1. open")
    public String open;
    @SerializedName("2. high")
    public String high;
    @SerializedName("3. low")
    public String low;
    @SerializedName("4. close")
    public String close;
    @SerializedName("5. volume")
    public String volume;

}

package com.payrails.model.response;

import com.google.gson.annotations.SerializedName;

public class MetaData {
    @SerializedName("1. Information")
    public String information;
    @SerializedName("2. Symbol")
    public String symbol;
    @SerializedName("3. Last Refreshed")
    public String lastRefreshed;
    @SerializedName("4. Interval")
    public String interval;
    @SerializedName("5. Output Size")
    public String outputSize;
    @SerializedName("6. Time Zone")
    public String timeZone;
}

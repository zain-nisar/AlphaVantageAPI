package com.payrails.tests.time_series_stock_data;

import java.util.HashMap;
import java.util.Map;

import org.apache.http.HttpStatus;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.google.gson.Gson;
import com.payrails.configmanager.ConfigUtils;
import com.payrails.configmanager.RestAssuredResource;
import com.payrails.model.response.TimeSeriesIntradayApiResponse;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

public class stockData_GetTimeSeriesIntraday_Test {

    @Test
    public void ValidateRequiredParameter_200() {
        Map<String, Object> configKeys = ConfigUtils.getEnvironmentInfoFromConfig();
        Map<String, Object> getEnvKeys = (Map<String, Object>)configKeys.get("env");
        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("function", "TIME_SERIES_INTRADAY");
        queryParams.put("symbol", "IBM");
        queryParams.put("interval", "1min");
        queryParams.put("apikey", (String) getEnvKeys.get("authentication_key"));
        var actualResponse = RestAssuredResource.get(
                (String) getEnvKeys.get("base_url") + (String) configKeys.get("base_api_path"),
                queryParams);

        Gson gson = new Gson();
        TimeSeriesIntradayApiResponse mappingResponse = gson.fromJson(actualResponse.getBody().asString(), TimeSeriesIntradayApiResponse.class);
        Assertions.assertEquals(HttpStatus.SC_OK, actualResponse.statusCode());

        Assertions.assertAll(
                () -> Assertions.assertEquals(mappingResponse.metaData.information, "Intraday (1min) open, high, low, close prices and volume"),
                () -> Assertions.assertEquals(mappingResponse.metaData.symbol, "IBM"),
                () -> Assertions.assertNotNull(mappingResponse.metaData.lastRefreshed),
                () -> Assertions.assertEquals(mappingResponse.metaData.interval, "1min"),
                () -> Assertions.assertEquals(mappingResponse.metaData.outputSize, "Compact"),
                () -> Assertions.assertEquals(mappingResponse.metaData.timeZone, "US/Eastern")
                //so on
        );
    }

    @ParameterizedTest(name = "#{index} - Run test with function={0}")
    @ValueSource(strings = {
            "",
            " ",
            "WRONGVALUE"
    })
    public void ValidateRequiredParameter_FunctionWithInvalidValue(String testData) {
        Map<String, Object> configKeys = ConfigUtils.getEnvironmentInfoFromConfig();
        Map<String, Object> getEnvKeys = (Map<String, Object>)configKeys.get("env");
        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("function", testData);
        queryParams.put("symbol", "IBM");
        queryParams.put("interval", "1min");
        queryParams.put("apikey", (String) getEnvKeys.get("authentication_key"));
        var actualResponse = RestAssuredResource.get(
                (String) getEnvKeys.get("base_url") + (String) configKeys.get("base_api_path"),
                queryParams);


        Assertions.assertEquals("[Error Message:This API function (" + testData + ") does not exist.]", actualResponse.jsonPath().getString(""));
    }
}